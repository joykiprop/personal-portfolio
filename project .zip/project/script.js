document.addEventListener("DOMContentLoaded", function () {
    alert("Welcome to my portfolio website!");
});
