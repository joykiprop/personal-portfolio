# Personal Portfolio Website

This is my first portfolio website built using HTML, CSS, and JavaScript.

## Pages:
- Home (me.html)
- About Me (about.html)
- Favorite Meals (recipe1.html, recipe2.html)

## Features:
- Responsive design
- Simple navigation
- Clean and structured code

## How to Run:
1. Open `me.html` in a browser.
2. Navigate through the pages using the menu.
